# personal-space2
"Space to Grow" is a farming/child-raising simulation visual novel game. It's the sequel to the marriage simulation game "Our Personal Space"

Space to Grow is (c)2021 Metasepia Games, <http://metasepiagames.com>. For license information, see the LICENSE file.
